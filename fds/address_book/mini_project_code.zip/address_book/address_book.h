#include <string>
#ifndef ADDRESS_BOOK_H
#define ADDRESS_BOOK_H
using namespace std;

void run_program();
void program();
void display_commands();
int get_menu_selection();
int get_menu_selection2();
string get_name();
string get_address();
int get_birth_year();
string get_phone_number();
string get_file_name();
#endif
