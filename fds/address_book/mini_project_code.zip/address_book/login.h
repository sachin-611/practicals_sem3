#include <string>
#ifndef LOGIN
#define LOGIN
bool login();
bool admin_login(std::string ,std::string);
#endif
